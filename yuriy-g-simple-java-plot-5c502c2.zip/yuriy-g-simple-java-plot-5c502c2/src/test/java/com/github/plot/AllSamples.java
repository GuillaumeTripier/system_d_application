package com.github.plot;

import java.io.IOException;

public class AllSamples {

	public static void main(String[] args) throws IOException {
		HelloWorld.main(args);
		MinimalPlotSample.main(args);
		AllOptsPlotSample.main(args);
		PlotDemo.main(args);
	}
	
}
